
module.exports = {
  wtoutFunction: (returnValue) => {
    if(returnValue.inUse) return 'failed!';
    return JSON.stringify(returnValue);
  }
}