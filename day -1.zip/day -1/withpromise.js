// use cases -> for asynchronous calls (like file operations, multithreading type operations)
// As JS is single threaded the only way to prevent clogging 


module.exports =  {
  promiseFunction: (returnValue) => {
    return new Promise((resolve, reject) => {
      if(returnValue.inUse) reject ('Failed! as inUse');
      resolve(JSON.stringify(returnValue));
    })
  }
};