
function addElement() {
  var msg = document.createElement("h2");
  var textNode = document.createTextNode('page 1');
  msg.appendChild(textNode);
  var app = document.getElementsByTagName('app-root');
  app[0].appendChild(msg);
}

function addApp() {
  addElement()
}

function convertBase64ToString(string){
  return window.atob(string);
}

function convertStringToBase64(string){
  return window.btoa(string);
}

function convertToString(){
  var base64 = document.getElementById('base64').value;
  console.log(base64);
  var string = convertBase64ToString(base64);
  document.getElementById('result').innerHTML = string;
}

function convertToBase64(){
  var string = document.getElementById('string').value;
  console.log(string);
  var base64 = convertStringToBase64(string);
  document.getElementById('result').innerHTML = base64
}
