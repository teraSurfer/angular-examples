const withPromise = require('./withpromise')
const withoutPromise = require('./wihtoutpromise')

const returnValue = {
  inUse: true,
  msg: 'Hello!'
}

const retVal = {
  inUse: false,
  msg: 'Hello'
}


withPromise.promiseFunction(returnValue).then((res)=>{
  console.log(res + '7')
}).catch(err => {
  console.log(err + '7')
})

withPromise.promiseFunction(retVal).then((res)=>{
  console.log(res + '5')
}).catch(err => {
  console.log(err + '5')
})
withPromise.promiseFunction(returnValue).then((res)=>{
  console.log(res + '8')
}).catch(err => {
  console.log(err + '8')
})
withPromise.promiseFunction(retVal).then((res)=>{
  console.log(res + '6')
}).catch(err => {
  console.log(err + '6')
})

console.log(withoutPromise.wtoutFunction(`${returnValue} from without promise 1`));
console.log(withoutPromise.wtoutFunction(`${retVal} from without promise 2`));
console.log(withoutPromise.wtoutFunction(`${returnValue} from without promise 3`));
console.log(withoutPromise.wtoutFunction(`${retVal} from without promise 4`));;


// var promise1 = new Promise(function(resolve, reject) {
//   setTimeout(reject, 100, 'foo');
// });

// console.log(promise1);
// // expected output: [object Promise]
// promise1.then((res) => {
// 	console.log(res)
// }).catch((err) => {
// 	console.log(err)
// })
