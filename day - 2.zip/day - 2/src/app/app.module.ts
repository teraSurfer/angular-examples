import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule, HttpClient } from '@angular/common/http';

import { AppComponent } from './app.component';
import { PageheaderComponent } from './pageheader/pageheader.component';
import { HeaderformComponent } from './headerform/headerform.component';
import { PlayersComponent } from './players/players.component';
import {NgbModule} from '@ng-bootstrap/ng-bootstrap';
import { UsersComponent } from './users/users.component';
import { UserService } from './user.service';


@NgModule({
  declarations: [
    AppComponent,
    PageheaderComponent,
    HeaderformComponent,
    PlayersComponent,
    UsersComponent
  ],
  imports: [
    BrowserModule,
    NgbModule.forRoot(),
    HttpClientModule
  ],
  providers: [UserService],
  bootstrap: [AppComponent]
})
export class AppModule { }
