import { Injectable } from '@angular/core';
// import { User } from './User';
import { HttpClient } from '@angular/common/http';

@Injectable()
export class UserService {

  apiUrl = 'https://randomuser.me/api';

  constructor(private http: HttpClient) { }

  getUsers (numberOfUsersToFetch) {
    return this.http.get(`${this.apiUrl}/?results=${numberOfUsersToFetch}`); // returns an observable object which contains users.
  }

}
