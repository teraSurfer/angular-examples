export class Player {
  id: number;
  name: string;
  category: number; // because string is hard to validate
}
