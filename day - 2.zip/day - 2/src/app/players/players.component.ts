import { Component, OnInit } from '@angular/core';
import { Player } from '../Player';

@Component({
  selector: 'app-players',
  templateUrl: './players.component.html',
  styleUrls: ['./players.component.css']
})
export class PlayersComponent implements OnInit {

  player: Player = {
    id: 129,
    name: 'XYZ',
    category: 2
  };

  multiPlayers: Player [] = [
    {
      id: 100,
      name: 'nice',
      category: 2
    },
    {
      id: 200,
      name: 'mr. happy',
      category: 4
    }
  ];
  constructor() { }

  ngOnInit() {
  }

}
