import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-headerform',
  templateUrl: './headerform.component.html',
  styleUrls: ['./headerform.component.css']
})
export class HeaderformComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
