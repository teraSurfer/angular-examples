import { Component, OnInit } from '@angular/core';
import { UserService } from '../user.service';
// import { User } from '../User';

@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.css']
})
export class UsersComponent implements OnInit {
  userData: any;
  constructor(usrService: UserService) {
    usrService.getUsers(3).subscribe((data: any) => {
      //  console.log(data);
       this.userData = data.results;
    }, (err) => {
      console.log(err);
    });
  }
  ngOnInit() {
  }

}
