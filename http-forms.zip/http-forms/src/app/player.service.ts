import { Injectable } from '@angular/core';
import {Player} from './player';
import {HttpClient} from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class PlayerService {

  private httpRoute = 'http://localhost:3000';
  constructor(private _http: HttpClient) { }
  getPlayers() {
    return this._http.get(`${this.httpRoute}/players`);
  }

  addPlayer(player: Player) {
    return this._http.post<Player>(`${this.httpRoute}/players`, player);
  }
}
