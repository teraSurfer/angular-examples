import { Component, OnInit } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {map} from 'rxjs/operators';
import {Player} from '../player';
import {PlayerService} from '../player.service';

@Component({
  selector: 'app-players',
  templateUrl: './players.component.html',
  styleUrls: ['./players.component.css']
})
export class PlayersComponent implements OnInit {
players: Player[];
  constructor(private service: PlayerService) {}

  ngOnInit() {
    this.service.getPlayers().subscribe(result => {
       this.players = result as Player[];
    }, err => {
      console.log(err);
    });
  }
}
