import { Component, OnInit } from '@angular/core';
import {Player} from '../player';
import {PlayerService} from '../player.service';

@Component({
  selector: 'app-addplayer',
  templateUrl: './addplayer.component.html',
  styleUrls: ['./addplayer.component.css']
})
export class AddplayerComponent implements OnInit {

private player: Player = {
  name: '',
  id: null,
  type: '',
  grade: '',
  country: '',
  img: ''
};

  constructor(private service: PlayerService) { }

  ngOnInit() {
  }
  onSubmit() {
    console.log(this.player);
    this.service.addPlayer(this.player).subscribe(res => {
      console.log(res);
    }, err => {
      console.log(err);
    });
  }
}
