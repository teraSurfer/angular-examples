export class Player {
  name: string;
  country: string;
  type: string;
  img: string;
  grade: string;
  id: number;
}
